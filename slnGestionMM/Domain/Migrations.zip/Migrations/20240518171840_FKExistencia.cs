﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Domain.Migrations
{
    /// <inheritdoc />
    public partial class FKExistencia : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            /*migrationBuilder.DropForeignKey(
                name: "FK_Existencias_Medias_MediaId",
                table: "Existencias");

            migrationBuilder.DropIndex(
                name: "IX_Existencias_MediaId",
                table: "Existencias");

            migrationBuilder.DropColumn(
                name: "MediaId",
                table: "Existencias");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "Medias",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .OldAnnotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddForeignKey(
                name: "FK_Medias_Existencias_Id",
                table: "Medias",
                column: "Id",
                principalTable: "Existencias",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);*/
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            /*migrationBuilder.DropForeignKey(
                name: "FK_Medias_Existencias_Id",
                table: "Medias");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "Medias",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddColumn<int>(
                name: "MediaId",
                table: "Existencias",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Existencias_MediaId",
                table: "Existencias",
                column: "MediaId");

            migrationBuilder.AddForeignKey(
                name: "FK_Existencias_Medias_MediaId",
                table: "Existencias",
                column: "MediaId",
                principalTable: "Medias",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);*/
        }
    }
}
