﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Domain.Migrations
{
    /// <inheritdoc />
    public partial class existencias : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Drop the existing primary key
            //migrationBuilder.DropPrimaryKey(
            //    name: "PK_AspNetUserTokens",
            //    table: "AspNetUserTokens");

            //migrationBuilder.DropPrimaryKey(
            //    name: "PK_AspNetUserLogins",
            //    table: "AspNetUserLogins");

            //migrationBuilder.AlterColumn<string>(
            //    name: "Name",
            //    table: "AspNetUserTokens",
            //    type: "nvarchar(128)",
            //    maxLength: 128,
            //    nullable: false,
            //    oldClrType: typeof(string),
            //    oldType: "nvarchar(450)");

            //migrationBuilder.AlterColumn<string>(
            //    name: "LoginProvider",
            //    table: "AspNetUserTokens",
            //    type: "nvarchar(128)",
            //    maxLength: 128,
            //    nullable: false,
            //    oldClrType: typeof(string),
            //    oldType: "nvarchar(450)");

            //migrationBuilder.AlterColumn<string>(
            //    name: "ProviderKey",
            //    table: "AspNetUserLogins",
            //    type: "nvarchar(128)",
            //    maxLength: 128,
            //    nullable: false,
            //    oldClrType: typeof(string),
            //    oldType: "nvarchar(450)");

            //migrationBuilder.AlterColumn<string>(
            //    name: "LoginProvider",
            //    table: "AspNetUserLogins",
            //    type: "nvarchar(128)",
            //    maxLength: 128,
            //    nullable: false,
            //    oldClrType: typeof(string),
            //    oldType: "nvarchar(450)");

            //// Add the primary key back
            //migrationBuilder.AddPrimaryKey(
            //    name: "PK_AspNetUserLogins",
            //    table: "AspNetUserLogins",
            //    columns: new[] { "LoginProvider", "ProviderKey" });

            //migrationBuilder.AddPrimaryKey(
            //    name: "PK_AspNetUserTokens",
            //    table: "AspNetUserTokens",
            //    columns: new[] { "UserId", "LoginProvider", "Name" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Drop the existing primary key
            //migrationBuilder.DropPrimaryKey(
            //    name: "PK_AspNetUserTokens",
            //    table: "AspNetUserTokens");

            //migrationBuilder.DropPrimaryKey(
            //    name: "PK_AspNetUserLogins",
            //    table: "AspNetUserLogins");

            //migrationBuilder.AlterColumn<string>(
            //    name: "Name",
            //    table: "AspNetUserTokens",
            //    type: "nvarchar(450)",
            //    nullable: false,
            //    oldClrType: typeof(string),
            //    oldType: "nvarchar(128)",
            //    oldMaxLength: 128);

            //migrationBuilder.AlterColumn<string>(
            //    name: "LoginProvider",
            //    table: "AspNetUserTokens",
            //    type: "nvarchar(450)",
            //    nullable: false,
            //    oldClrType: typeof(string),
            //    oldType: "nvarchar(128)",
            //    oldMaxLength: 128);

            //migrationBuilder.AlterColumn<string>(
            //    name: "ProviderKey",
            //    table: "AspNetUserLogins",
            //    type: "nvarchar(450)",
            //    nullable: false,
            //    oldClrType: typeof(string),
            //    oldType: "nvarchar(128)",
            //    oldMaxLength: 128);

            //migrationBuilder.AlterColumn<string>(
            //    name: "LoginProvider",
            //    table: "AspNetUserLogins",
            //    type: "nvarchar(450)",
            //    nullable: false,
            //    oldClrType: typeof(string),
            //    oldType: "nvarchar(128)",
            //    oldMaxLength: 128);

            //// Add the primary key back
            //migrationBuilder.AddPrimaryKey(
            //    name: "PK_AspNetUserTokens",
            //    table: "AspNetUserTokens",
            //    columns: new[] { "UserId", "LoginProvider", "Name" });

            //migrationBuilder.AddPrimaryKey(
            //    name: "PK_AspNetUserLogins",
            //    table: "AspNetUserLogins",
            //    columns: new[] { "LoginProvider", "ProviderKey" });
        }
    }
}
